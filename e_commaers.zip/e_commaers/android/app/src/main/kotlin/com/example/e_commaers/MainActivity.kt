package com.example.e_commaers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
